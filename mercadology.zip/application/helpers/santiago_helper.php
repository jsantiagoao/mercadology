<?php

function getnombre(){
	return "<h1>Jose Santiago Aguillon Olvera Ingeniero</h1>";
}


?>